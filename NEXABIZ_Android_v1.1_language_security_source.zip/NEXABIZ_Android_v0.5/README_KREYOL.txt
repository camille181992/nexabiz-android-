NEXABIZ Android v1.1 — Kòd sous devlopman

Nouvo nan v1.1:
- Chwa lang aplikasyon: Kreyòl ayisyen, Franse, Anglè, Panyòl.
- Lang chwazi a konsève nan bazdone lokal la.
- Bouton lang disponib nan meni anlè aplikasyon an apre koneksyon.
- Limit tantativ koneksyon: apre 5 tantativ ki pa reyisi pou yon non itilizatè, koneksyon an bloke pandan 5 minit.
- Tantativ koneksyon ki echwe antre nan jounal kontwòl la.

Sa ki enpòtan pou konnen:
- Nan etap sa a, tradiksyon yo aplike nan navigasyon prensipal la; rès ekran ak tout resi/rapò poko tradui nèt. Sa rete yon travay obligatwa anvan APK final.
- Pwoteksyon tantativ koneksyon sa a se yon baryè lokal sou aparèy la, li pa ranplase yon odit sekirite konplè.
- Modpas nan bazdone vèsyon sa a toujou sèvi ak SHA-256 ak sèl lokal; anvan itilizasyon reyèl, fòk nou ranfòse sa ak yon fonksyon derivasyon kle ki fèt pou modpas, epi teste li.
- Sovgad la poko chifre. Pa mete done reyèl kliyan oswa anplwaye nan vèsyon tès sa a.
- Pa gen tès konpilasyon Android ki fèt nan achiv sa a. Se kòd sous Flutter, se pa APK.

Kijan pou itilize:
1. Ekstrè ZIP sa a.
2. Louvri pwojè a nan Flutter.
3. Kouri `flutter pub get`.
4. Kouri tès/analiz ak `flutter analyze` ak `flutter test`.
5. Apre koreksyon tout erè yo, konstwi APK debug pou teste sou aparèy Android.

Pwojè sa a se yon baz devlopman. Pa sèvi avè l pou tranzaksyon reyèl anvan tès ak verifikasyon sekirite.
