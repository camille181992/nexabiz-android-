import 'dart:convert';
import 'dart:math';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.init();
  final saved = await AppDb.instance.setting('language') ?? 'ht';
  NexaLocale.code.value = saved;
  runApp(const NexaBizApp());
}

class NexaLocale { static final ValueNotifier<String> code = ValueNotifier<String>('ht'); }

class AppDb {
  AppDb._();
  static final instance = AppDb._();
  Database? _db;
  Database get db => _db!;
  final secure = const FlutterSecureStorage();

  Future<void> init() async {
    final root = await getDatabasesPath();
    _db = await openDatabase(p.join(root, 'nexabiz_local.db'), version: 5,
      onCreate: (d, v) async {
        await d.execute('''CREATE TABLE users(id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, full_name TEXT NOT NULL, role TEXT NOT NULL, salt TEXT NOT NULL, pass_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE products(id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, price REAL NOT NULL, stock REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE sales(id TEXT PRIMARY KEY, receipt_no TEXT UNIQUE NOT NULL, cashier_id TEXT NOT NULL, total REAL NOT NULL, amount_received REAL NOT NULL, change_given REAL NOT NULL, payment_method TEXT NOT NULL, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE sale_items(id TEXT PRIMARY KEY, sale_id TEXT NOT NULL, product_id TEXT NOT NULL, product_name TEXT NOT NULL, quantity REAL NOT NULL, unit_price REAL NOT NULL, line_total REAL NOT NULL)''');
        await d.execute('''CREATE TABLE cash_sessions(id TEXT PRIMARY KEY, user_id TEXT NOT NULL, opening_cash REAL NOT NULL, opened_at TEXT NOT NULL, closed_at TEXT, counted_cash REAL, expected_cash REAL)''');
        await d.execute('''CREATE TABLE expenses(id TEXT PRIMARY KEY, user_id TEXT NOT NULL, label TEXT NOT NULL, amount REAL NOT NULL, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE audit_logs(id TEXT PRIMARY KEY, user_id TEXT, action TEXT NOT NULL, details TEXT NOT NULL, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE business_profile(id INTEGER PRIMARY KEY CHECK(id=1), business_name TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', logo_path TEXT, currency TEXT NOT NULL DEFAULT 'HTG')''');
        await d.execute('''CREATE TABLE employees(id TEXT PRIMARY KEY, employee_code TEXT UNIQUE NOT NULL, full_name TEXT NOT NULL, phone TEXT, job_title TEXT, base_salary REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE attendance(id TEXT PRIMARY KEY, employee_id TEXT NOT NULL, check_in TEXT, check_out TEXT, scheduled_start TEXT, late_minutes INTEGER NOT NULL DEFAULT 0, note TEXT, recorded_by TEXT NOT NULL, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE payroll(id TEXT PRIMARY KEY, employee_id TEXT NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, base_amount REAL NOT NULL, additions REAL NOT NULL DEFAULT 0, deductions REAL NOT NULL DEFAULT 0, net_amount REAL NOT NULL, status TEXT NOT NULL DEFAULT 'pending', paid_at TEXT, paid_by TEXT, note TEXT, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE returns(id TEXT PRIMARY KEY, sale_id TEXT NOT NULL, sale_item_id TEXT NOT NULL, product_id TEXT NOT NULL, quantity REAL NOT NULL, refund_amount REAL NOT NULL, stock_action TEXT NOT NULL, reason TEXT NOT NULL, processed_by TEXT NOT NULL, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE cash_movements(id TEXT PRIMARY KEY, session_id TEXT NOT NULL, user_id TEXT NOT NULL, movement_type TEXT NOT NULL, payment_method TEXT NOT NULL, amount REAL NOT NULL, description TEXT NOT NULL, created_at TEXT NOT NULL)''');
        await d.execute('''CREATE TABLE app_settings(setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL)''');
        await d.execute("INSERT INTO business_profile(id,business_name) VALUES(1, 'BENCIA MULTI SERVICES')");
        await d.execute('CREATE INDEX idx_sales_date ON sales(created_at)');
        await d.execute('CREATE INDEX idx_items_sale ON sale_items(sale_id)');
        await d.execute('CREATE INDEX idx_attendance_employee_date ON attendance(employee_id, created_at)');
        await d.execute('CREATE INDEX idx_payroll_employee_period ON payroll(employee_id, period_start, period_end)');
      },
      onUpgrade: (d, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await d.execute('''CREATE TABLE business_profile(id INTEGER PRIMARY KEY CHECK(id=1), business_name TEXT NOT NULL DEFAULT '', address TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', logo_path TEXT, currency TEXT NOT NULL DEFAULT 'HTG')''');
          await d.execute('''CREATE TABLE employees(id TEXT PRIMARY KEY, employee_code TEXT UNIQUE NOT NULL, full_name TEXT NOT NULL, phone TEXT, job_title TEXT, base_salary REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)''');
          await d.execute('''CREATE TABLE attendance(id TEXT PRIMARY KEY, employee_id TEXT NOT NULL, check_in TEXT, check_out TEXT, scheduled_start TEXT, late_minutes INTEGER NOT NULL DEFAULT 0, note TEXT, recorded_by TEXT NOT NULL, created_at TEXT NOT NULL)''');
          await d.execute('''CREATE TABLE payroll(id TEXT PRIMARY KEY, employee_id TEXT NOT NULL, period_start TEXT NOT NULL, period_end TEXT NOT NULL, base_amount REAL NOT NULL, additions REAL NOT NULL DEFAULT 0, deductions REAL NOT NULL DEFAULT 0, net_amount REAL NOT NULL, status TEXT NOT NULL DEFAULT 'pending', paid_at TEXT, paid_by TEXT, note TEXT, created_at TEXT NOT NULL)''');
          await d.execute('''CREATE TABLE returns(id TEXT PRIMARY KEY, sale_id TEXT NOT NULL, sale_item_id TEXT NOT NULL, product_id TEXT NOT NULL, quantity REAL NOT NULL, refund_amount REAL NOT NULL, stock_action TEXT NOT NULL, reason TEXT NOT NULL, processed_by TEXT NOT NULL, created_at TEXT NOT NULL)''');
          await d.execute('''CREATE TABLE cash_movements(id TEXT PRIMARY KEY, session_id TEXT NOT NULL, user_id TEXT NOT NULL, movement_type TEXT NOT NULL, payment_method TEXT NOT NULL, amount REAL NOT NULL, description TEXT NOT NULL, created_at TEXT NOT NULL)''');
          await d.execute('''CREATE TABLE app_settings(setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL)''');
          await d.execute("INSERT INTO business_profile(id,business_name) VALUES(1, 'BENCIA MULTI SERVICES')");
          await d.execute('CREATE INDEX idx_attendance_employee_date ON attendance(employee_id, created_at)');
          await d.execute('CREATE INDEX idx_payroll_employee_period ON payroll(employee_id, period_start, period_end)');
        }
        if (oldVersion < 3) {
          await d.execute('CREATE INDEX IF NOT EXISTS idx_cash_sessions_user ON cash_sessions(user_id, opened_at)');
          await d.execute('CREATE INDEX IF NOT EXISTS idx_cash_movements_session ON cash_movements(session_id, created_at)');
        }
        if (oldVersion < 4) { await d.execute('CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(created_at)'); }
        if (oldVersion < 5) { await d.execute('CREATE INDEX IF NOT EXISTS idx_returns_sale_item ON returns(sale_item_id)'); }
      });
  }

  String _salt() {
    final r = Random.secure();
    return base64UrlEncode(List<int>.generate(24, (_) => r.nextInt(256)));
  }
  String _hash(String password, String salt) => sha256.convert(utf8.encode('$salt:$password')).toString();

  Future<bool> hasUsers() async => (Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM users')) ?? 0) > 0;
  Future<void> createAdmin(String name, String username, String password) async {
    final salt = _salt();
    await db.insert('users', {'id': const Uuid().v4(), 'username': username.trim().toLowerCase(), 'full_name': name.trim(), 'role': 'admin', 'salt': salt, 'pass_hash': _hash(password, salt), 'created_at': DateTime.now().toIso8601String()});
  }
  Future<String?> setting(String key) async {
    final rows = await db.query('app_settings', where: 'setting_key=?', whereArgs: [key], limit: 1);
    return rows.isEmpty ? null : rows.first['setting_value'] as String;
  }
  Future<void> saveSetting(String key, String value) async => db.insert('app_settings', {'setting_key': key, 'setting_value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<Map<String, Object?>?> login(String username, String password) async {
    final normalized = username.trim().toLowerCase();
    final lockKey = 'login_lock_$normalized';
    final failKey = 'login_fail_$normalized';
    final lockedUntil = int.tryParse((await setting(lockKey)) ?? '') ?? 0;
    if (DateTime.now().millisecondsSinceEpoch < lockedUntil) {
      throw Exception('Twòp tantativ. Eseye ankò nan kèk minit.');
    }
    final rows = await db.query('users', where: 'username=? AND active=1', whereArgs: [normalized], limit: 1);
    if (rows.isEmpty || _hash(password, rows.first['salt'] as String) != rows.first['pass_hash']) {
      final failures = (int.tryParse((await setting(failKey)) ?? '0') ?? 0) + 1;
      await saveSetting(failKey, '$failures');
      await log(null, 'LOGIN_FAILED', 'Echèk koneksyon pou non itilizatè: $normalized');
      if (failures >= 5) {
        await saveSetting(lockKey, '${DateTime.now().add(const Duration(minutes: 5)).millisecondsSinceEpoch}');
        await saveSetting(failKey, '0');
        throw Exception('Kont lan bloke pandan 5 minit apre 5 tantativ ki pa reyisi.');
      }
      return null;
    }
    await saveSetting(failKey, '0');
    await saveSetting(lockKey, '0');
    final u = rows.first;
    await log(u['id'] as String, 'LOGIN', 'Koneksyon reyisi');
    return u;
  }
  Future<void> log(String? user, String action, String details) async => db.insert('audit_logs', {'id': const Uuid().v4(), 'user_id': user, 'action': action, 'details': details, 'created_at': DateTime.now().toIso8601String()});
  Future<List<Map<String, Object?>>> allUsers() => db.query('users', columns: ['id','username','full_name','role','active','created_at'], orderBy: 'role, full_name');
  Future<void> createStaffUser(String name, String username, String password, String role, String adminId) async {
    if (!['admin','cashier','stock_manager'].contains(role)) throw Exception('Wòl sa a pa disponib.');
    if (name.trim().isEmpty || username.trim().isEmpty || password.length < 8) throw Exception('Non, itilizatè ak modpas 8 karaktè obligatwa.');
    final salt = _salt();
    await db.insert('users', {'id': const Uuid().v4(), 'username': username.trim().toLowerCase(), 'full_name': name.trim(), 'role': role, 'salt': salt, 'pass_hash': _hash(password, salt), 'created_at': DateTime.now().toIso8601String()});
    await log(adminId, 'USER_CREATE', 'Kreye kont ${role}: ${username.trim()}');
  }
  Future<void> setUserActive(String targetId, bool active, String adminId) async {
    final target = await db.query('users', where: 'id=?', whereArgs: [targetId], limit: 1);
    if (target.isEmpty) return;
    if (target.first['role'] == 'admin' && active == false) {
      final count = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1")) ?? 0;
      if (count <= 1) throw Exception('Ou pa ka dezaktive dènye administratè aktif la.');
    }
    await db.update('users', {'active': active ? 1 : 0}, where: 'id=?', whereArgs: [targetId]);
    await log(adminId, active ? 'USER_ACTIVATE' : 'USER_SUSPEND', 'Kont ${target.first['username']}');
  }
  Future<Map<String, Object?>> businessProfile() async {
    final rows = await db.query('business_profile', where: 'id=1', limit: 1);
    return rows.isEmpty ? {'business_name':'', 'address':'', 'phone':'', 'currency':'HTG'} : rows.first;
  }
  Future<void> saveBusinessProfile(String name, String address, String phone, String adminId) async {
    await db.update('business_profile', {'business_name':name.trim(), 'address':address.trim(), 'phone':phone.trim()}, where: 'id=1');
    await log(adminId, 'BUSINESS_PROFILE_UPDATE', 'Mizajou enfòmasyon biznis la.');
  }
  Future<Map<String, Object?>> adminSummary() async {
    final sales = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM sales')) ?? 0;
    final revenue = (Sqflite.firstIntValue(await db.rawQuery('SELECT CAST(COALESCE(SUM(total),0) AS INTEGER) FROM sales')) ?? 0);
    final users = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM users WHERE active=1')) ?? 0;
    final products = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE active=1')) ?? 0;
    return {'sales':sales,'revenue':revenue,'users':users,'products':products};
  }
  Future<String> nextCode() async {
    final n = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products')) ?? 0;
    return 'NX${(n + 1).toString().padLeft(6, '0')}';
  }
  Future<void> addProduct(String name, double price, double stock, String userId) async {
    final code = await nextCode();
    await db.insert('products', {'id': const Uuid().v4(), 'code': code, 'name': name.trim(), 'price': price, 'stock': stock, 'created_at': DateTime.now().toIso8601String()});
    await log(userId, 'PRODUCT_ADD', '$code - $name');
  }
  Future<List<Map<String, Object?>>> products() => db.query('products', where: 'active=1', orderBy: 'name');
  Future<List<Map<String, Object?>>> recentSales() => db.rawQuery('''SELECT sales.*, users.full_name AS cashier_name FROM sales LEFT JOIN users ON users.id=sales.cashier_id ORDER BY sales.created_at DESC LIMIT 100''');
  Future<Map<String,Object?>?> activeCashSession(String userId) async {
    final rows = await db.query('cash_sessions', where: 'user_id=? AND closed_at IS NULL', whereArgs:[userId], orderBy:'opened_at DESC', limit:1);
    return rows.isEmpty ? null : rows.first;
  }
  Future<void> openCashSession(String userId, double openingCash) async {
    if (openingCash < 0) throw Exception('Kantite ouvèti a pa ka negatif.');
    if (await activeCashSession(userId) != null) throw Exception('Ou deja gen yon kès ki ouvè.');
    final id=const Uuid().v4();
    await db.insert('cash_sessions', {'id':id,'user_id':userId,'opening_cash':openingCash,'opened_at':DateTime.now().toIso8601String()});
    await log(userId,'CASH_OPEN','Ouvèti kès: $openingCash G');
  }
  Future<Map<String,Object?>> cashSessionReport(String sessionId) async {
    final rows=await db.query('cash_sessions',where:'id=?',whereArgs:[sessionId],limit:1);
    if(rows.isEmpty) throw Exception('Sesyon kès la pa jwenn.');
    final session=rows.first;
    final sales=await db.rawQuery("SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS count FROM sales WHERE cashier_id=? AND created_at>=? AND (? IS NULL OR created_at<=?)",[session['user_id'],session['opened_at'],session['closed_at'],session['closed_at']]);
    final cashSales=(await db.rawQuery("SELECT COALESCE(SUM(total),0) AS total FROM sales WHERE cashier_id=? AND payment_method='Kach' AND created_at>=? AND (? IS NULL OR created_at<=?)",[session['user_id'],session['opened_at'],session['closed_at'],session['closed_at']])).first['total'] as num;
    final movements=await db.rawQuery("SELECT COALESCE(SUM(CASE WHEN movement_type='IN' THEN amount ELSE -amount END),0) AS net FROM cash_movements WHERE session_id=? AND payment_method='Kach'",[sessionId]);
    final opening=(session['opening_cash'] as num).toDouble();
    final expected=opening+cashSales.toDouble()+(movements.first['net'] as num).toDouble();
    return {'opening':opening,'sales_total':(sales.first['total'] as num).toDouble(),'sales_count':sales.first['count'],'cash_sales':cashSales.toDouble(),'expected':expected,'closed_at':session['closed_at']};
  }
  Future<void> closeCashSession(String sessionId,double countedCash,String adminOrCashierId) async {
    final report=await cashSessionReport(sessionId);
    final expected=(report['expected'] as num).toDouble();
    await db.update('cash_sessions',{'closed_at':DateTime.now().toIso8601String(),'counted_cash':countedCash,'expected_cash':expected},where:'id=?',whereArgs:[sessionId]);
    await log(adminOrCashierId,'CASH_CLOSE','Kès fèmen. Atann: $expected G; konte: $countedCash G; diferans: ${countedCash-expected} G');
  }
  Future<List<Map<String,Object?>>> cashSessions() => db.rawQuery('''SELECT cash_sessions.*, users.full_name FROM cash_sessions LEFT JOIN users ON users.id=cash_sessions.user_id ORDER BY opened_at DESC LIMIT 100''');

  Future<void> addExpense(String label, double amount, String userId) async {
    if (label.trim().isEmpty || amount <= 0) throw Exception('Bay yon deskripsyon ak yon montan ki pi gran pase zewo.');
    await db.insert('expenses', {'id':const Uuid().v4(),'user_id':userId,'label':label.trim(),'amount':amount,'created_at':DateTime.now().toIso8601String()});
    await log(userId,'EXPENSE_ADD','Depans: ${label.trim()} • $amount G');
  }
  Future<List<Map<String,Object?>>> expenses() => db.rawQuery("SELECT expenses.*, users.full_name FROM expenses LEFT JOIN users ON users.id=expenses.user_id ORDER BY expenses.created_at DESC LIMIT 200");
  Future<Map<String,Object?>> financeSummary() async {
    final sales=(await db.rawQuery('SELECT COALESCE(SUM(total),0) AS v, COUNT(*) AS n FROM sales')).first;
    final costs=(await db.rawQuery('SELECT COALESCE(SUM(amount),0) AS v FROM expenses')).first;
    final payroll=(await db.rawQuery("SELECT COALESCE(SUM(net_amount),0) AS v FROM payroll WHERE status='paid'")).first;
    final refunds=(await db.rawQuery('SELECT COALESCE(SUM(refund_amount),0) AS v FROM returns')).first;
    final revenue=(sales['v'] as num).toDouble(); final expense=(costs['v'] as num).toDouble();
    final paidPayroll=(payroll['v'] as num).toDouble(); final refund=(refunds['v'] as num).toDouble();
    return {'sales':revenue,'count':sales['n'],'expenses':expense,'payroll':paidPayroll,'refunds':refund,'net_before_stock_cost':revenue-expense-paidPayroll-refund};
  }

  Future<List<Map<String,Object?>>> employees() => db.query('employees', orderBy:'full_name');
  Future<void> addEmployee(String name,String phone,String job,double salary,String actor) async {
    if(name.trim().isEmpty || salary<0) throw Exception('Non anplwaye obligatwa; salè pa ka negatif.');
    final count=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM employees'))??0;
    final code='EMP${(count+1).toString().padLeft(5,'0')}';
    await db.insert('employees',{'id':const Uuid().v4(),'employee_code':code,'full_name':name.trim(),'phone':phone.trim(),'job_title':job.trim(),'base_salary':salary,'created_at':DateTime.now().toIso8601String()});
    await log(actor,'EMPLOYEE_ADD','$code • ${name.trim()}');
  }
  Future<void> setEmployeeActive(String id,bool active,String actor) async { await db.update('employees',{'active':active?1:0},where:'id=?',whereArgs:[id]); await log(actor,'EMPLOYEE_STATUS','Anplwaye $id: ${active?'aktif':'sispann'}'); }
  Future<List<Map<String,Object?>>> attendanceRows() => db.rawQuery('''SELECT attendance.*, employees.full_name, employees.employee_code FROM attendance JOIN employees ON employees.id=attendance.employee_id ORDER BY attendance.created_at DESC LIMIT 300''');
  Future<void> clockIn(String employeeId,String actor,DateTime? scheduled) async {
    final open=await db.query('attendance',where:'employee_id=? AND check_out IS NULL',whereArgs:[employeeId],limit:1);
    if(open.isNotEmpty) throw Exception('Anplwaye sa a deja gen prezans ki poko fèmen.');
    final now=DateTime.now(); int late=0;
    if(scheduled!=null && now.isAfter(scheduled)) late=now.difference(scheduled).inMinutes;
    await db.insert('attendance',{'id':const Uuid().v4(),'employee_id':employeeId,'check_in':now.toIso8601String(),'scheduled_start':scheduled?.toIso8601String(),'late_minutes':late,'recorded_by':actor,'created_at':now.toIso8601String()});
    await log(actor,'ATTENDANCE_IN','Prezans anrejistre; reta: $late minit.');
  }
  Future<void> clockOut(String attendanceId,String actor) async { await db.update('attendance',{'check_out':DateTime.now().toIso8601String()},where:'id=? AND check_out IS NULL',whereArgs:[attendanceId]); await log(actor,'ATTENDANCE_OUT','Fen prezans $attendanceId'); }
  Future<List<Map<String,Object?>>> payrollRows() => db.rawQuery('''SELECT payroll.*, employees.full_name, employees.employee_code FROM payroll JOIN employees ON employees.id=payroll.employee_id ORDER BY payroll.created_at DESC''');
  Future<void> createPayroll(String employeeId,double base,double additions,double deductions,String start,String end,String note,String actor) async {
    if(base<0||additions<0||deductions<0||deductions>base+additions) throw Exception('Verifye montan salè ak dediksyon yo.');
    final net=base+additions-deductions;
    await db.insert('payroll',{'id':const Uuid().v4(),'employee_id':employeeId,'period_start':start,'period_end':end,'base_amount':base,'additions':additions,'deductions':deductions,'net_amount':net,'status':'pending','note':note,'created_at':DateTime.now().toIso8601String()});
    await log(actor,'PAYROLL_CREATE','Fich salè: $start - $end • Net: $net G. Dediksyon dwe verifye ak kontra/lalwa avan apwobasyon.');
  }
  Future<void> markPayrollPaid(String id,String actor) async { await db.update('payroll',{'status':'paid','paid_at':DateTime.now().toIso8601String(),'paid_by':actor},where:"id=? AND status='pending'",whereArgs:[id]); await log(actor,'PAYROLL_PAID','Peman salè $id make kòm peye.'); }
  Future<List<Map<String,Object?>>> salesWithItems() => db.rawQuery('''SELECT sales.*, users.full_name AS cashier_name FROM sales LEFT JOIN users ON users.id=sales.cashier_id ORDER BY sales.created_at DESC LIMIT 100''');
  Future<List<Map<String,Object?>>> itemsForSale(String saleId) => db.query('sale_items',where:'sale_id=?',whereArgs:[saleId]);
  Future<void> processReturn(Map<String,Object?> item,String saleId,double qty,String reason,String stockAction,String actor) async {
    final sold=(item['quantity'] as num).toDouble();
    final prior=await db.rawQuery('SELECT COALESCE(SUM(quantity),0) AS q FROM returns WHERE sale_item_id=?',[item['id']]);
    final already=(prior.first['q'] as num).toDouble();
    if(qty<=0 || qty>sold-already) throw Exception('Kantite retou a depase kantite ki te vann epi ki poko retounen.');
    final refund=qty*(item['unit_price'] as num).toDouble();
    await db.transaction((txn) async {
      await txn.insert('returns',{'id':const Uuid().v4(),'sale_id':saleId,'sale_item_id':item['id'],'product_id':item['product_id'],'quantity':qty,'refund_amount':refund,'stock_action':stockAction,'reason':reason,'processed_by':actor,'created_at':DateTime.now().toIso8601String()});
      if(stockAction=='RESTOCK') await txn.rawUpdate('UPDATE products SET stock=stock+? WHERE id=?',[qty,item['product_id']]);
      await txn.insert('audit_logs',{'id':const Uuid().v4(),'user_id':actor,'action':'SALE_RETURN','details':'Retou ${item['product_name']} • $qty • Ranbousman: $refund G • Stok: $stockAction • $reason','created_at':DateTime.now().toIso8601String()});
    });
  }
  Future<List<Map<String,Object?>>> returnRows() => db.rawQuery('''SELECT returns.*, employees.full_name AS unused_name FROM returns LEFT JOIN employees ON employees.id=returns.processed_by ORDER BY returns.created_at DESC LIMIT 200''');
  Future<void> exportBackup() async {
    final tables=['users','products','sales','sale_items','cash_sessions','expenses','audit_logs','business_profile','employees','attendance','payroll','returns','cash_movements','app_settings'];
    final data=<String,dynamic>{'format':'NEXABIZ_BACKUP','version':1,'created_at':DateTime.now().toIso8601String(),'tables':<String,dynamic>{}};
    for(final t in tables){data['tables'][t]=await db.query(t);}
    final dir=await getDatabasesPath(); final file=File(p.join(dir,'NEXABIZ_backup_${DateTime.now().millisecondsSinceEpoch}.json'));
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
    await Share.shareXFiles([XFile(file.path)],text:'Sovgad done NEXABIZ. Kenbe fichye sa a an sekirite.');
    await log(null,'BACKUP_EXPORT','Sovgad JSON ekspòte.');
  }
  Future<void> importBackup() async {
    final picked=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);
    if(picked==null) return;
    final bytes=picked.files.single.bytes;
    if(bytes==null) throw Exception('Pa kapab li fichye sovgad la.');
    final decoded=jsonDecode(utf8.decode(bytes)) as Map<String,dynamic>;
    if(decoded['format']!='NEXABIZ_BACKUP' || decoded['tables'] is! Map) throw Exception('Fichye sa a pa yon sovgad NEXABIZ valab.');
    final tables=decoded['tables'] as Map<String,dynamic>;
    const order=['users','products','sales','sale_items','cash_sessions','expenses','audit_logs','business_profile','employees','attendance','payroll','returns','cash_movements','app_settings'];
    await db.transaction((txn) async {
      for(final t in order.reversed){await txn.delete(t);}
      for(final t in order){final rows=tables[t]; if(rows is List){for(final row in rows){await txn.insert(t,Map<String,Object?>.from(row as Map));}}}
    });
    await log(null,'BACKUP_IMPORT','Sovgad retabli.');
  }
  Future<void> checkout(Map<String, Object?> user, List<CartLine> cart, double received, String method) async {
    final total = cart.fold<double>(0, (s, x) => s + x.qty * x.price);
    if (cart.isEmpty || received < total) throw Exception('Montan resevwa a pa sifi.');
    await db.transaction((txn) async {
      for (final line in cart) {
        final rows = await txn.query('products', where: 'id=?', whereArgs: [line.id], limit: 1);
        if (rows.isEmpty || (rows.first['stock'] as num).toDouble() < line.qty) throw Exception('Stòk ensifizan pou ${line.name}.');
      }
      final id = const Uuid().v4();
      final receipt = 'NB-${DateTime.now().millisecondsSinceEpoch}';
      await txn.insert('sales', {'id': id, 'receipt_no': receipt, 'cashier_id': user['id'], 'total': total, 'amount_received': received, 'change_given': received-total, 'payment_method': method, 'created_at': DateTime.now().toIso8601String()});
      for (final line in cart) {
        await txn.insert('sale_items', {'id': const Uuid().v4(), 'sale_id': id, 'product_id': line.id, 'product_name': line.name, 'quantity': line.qty, 'unit_price': line.price, 'line_total': line.qty*line.price});
        await txn.rawUpdate('UPDATE products SET stock=stock-? WHERE id=?', [line.qty, line.id]);
      }
      await txn.insert('audit_logs', {'id': const Uuid().v4(), 'user_id': user['id'], 'action': 'SALE', 'details': '$receipt | Total: $total | Resevwa: $received | Monnen: ${received-total}', 'created_at': DateTime.now().toIso8601String()});
    });
  }
}

class CartLine { CartLine(this.id, this.name, this.price, this.stock); final String id,name; final double price,stock; double qty=1; }

class NexaBizApp extends StatelessWidget {
  const NexaBizApp({super.key});
  @override Widget build(BuildContext context) => ValueListenableBuilder<String>(valueListenable:NexaLocale.code, builder:(context,code,_) => MaterialApp(title:'NEXABIZ', locale:Locale(code), supportedLocales:const [Locale('ht'),Locale('fr'),Locale('en'),Locale('es')], debugShowCheckedModeBanner:false, theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor: const Color(0xff145a45)), useMaterial3:true), home:const Gate()));
}

class NexaLanguage {
  static const supported = {'ht':'Kreyòl','fr':'Français','en':'English','es':'Español'};
  static const words = <String, Map<String,String>>{
    'ht': {'home':'Akèy','products':'Pwodwi','sell':'Vann','cash':'Kès mwen','sales':'Rapò lavant','admin':'Administratè','audit':'Jounal','language':'Lang aplikasyon','logout':'Dekonekte','greeting':'Bonjou'},
    'fr': {'home':'Accueil','products':'Produits','sell':'Vendre','cash':'Ma caisse','sales':'Rapports de ventes','admin':'Administration','audit':'Journal','language':'Langue de l’application','logout':'Déconnexion','greeting':'Bonjour'},
    'en': {'home':'Home','products':'Products','sell':'Sell','cash':'My register','sales':'Sales reports','admin':'Administration','audit':'Audit log','language':'App language','logout':'Log out','greeting':'Hello'},
    'es': {'home':'Inicio','products':'Productos','sell':'Vender','cash':'Mi caja','sales':'Informes de ventas','admin':'Administración','audit':'Registro de auditoría','language':'Idioma de la aplicación','logout':'Cerrar sesión','greeting':'Hola'},
  };
  static String text(BuildContext context, String key) {
    final code = Localizations.localeOf(context).languageCode;
    return words[code]?[key] ?? words['ht']![key] ?? key;
  }
}

class Gate extends StatefulWidget { const Gate({super.key}); @override State<Gate> createState()=>_GateState(); }
class _GateState extends State<Gate> {
  bool? ready;
  @override void initState(){super.initState(); AppDb.instance.hasUsers().then((v){if(mounted)setState(()=>ready=v);});}
  @override Widget build(BuildContext context){if(ready==null)return const Scaffold(body:Center(child:CircularProgressIndicator())); return ready! ? LoginPage(onLogin:(u)=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>HomePage(user:u)))) : SetupPage(onDone:()=>setState(()=>ready=true));}
}

class SetupPage extends StatefulWidget { const SetupPage({super.key,required this.onDone}); final VoidCallback onDone; @override State<SetupPage> createState()=>_SetupPageState(); }
class _SetupPageState extends State<SetupPage>{final name=TextEditingController(), user=TextEditingController(), pass=TextEditingController(); bool busy=false;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Premye konfigirasyon NEXABIZ')),body:ListView(padding:const EdgeInsets.all(20),children:[const Text('Kreye premye kont administratè a. Se kont sa a k ap gen tout dwa administrasyon lokal yo.'),const SizedBox(height:16),TextField(controller:name,decoration:const InputDecoration(labelText:'Non administratè')),TextField(controller:user,decoration:const InputDecoration(labelText:'Non itilizatè')),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Modpas (omwen 8 karaktè)')),const SizedBox(height:20),FilledButton(onPressed:busy?null:()async{if(name.text.trim().isEmpty||user.text.trim().isEmpty||pass.text.length<8){ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Ranpli tout chan yo; modpas la dwe gen 8 karaktè.')));return;}setState(()=>busy=true);try{await AppDb.instance.createAdmin(name.text,user.text,pass.text);widget.onDone();}catch(e){ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('Erè: $e')));}finally{if(mounted)setState(()=>busy=false);}},child:const Text('Kreye kont administratè'))]));}

class LoginPage extends StatefulWidget { const LoginPage({super.key,required this.onLogin}); final ValueChanged<Map<String,Object?>> onLogin; @override State<LoginPage> createState()=>_LoginPageState(); }
class _LoginPageState extends State<LoginPage>{final user=TextEditingController(), pass=TextEditingController(); bool busy=false;
 @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:420),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.storefront,size:64),const SizedBox(height:8),Text('NEXABIZ',style:Theme.of(c).textTheme.headlineLarge),const Text('Tout biznis ou, yon sèl sistèm.'),const SizedBox(height:24),TextField(controller:user,decoration:const InputDecoration(labelText:'Non itilizatè')),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Modpas')),const SizedBox(height:18),FilledButton(onPressed:busy?null:()async{setState(()=>busy=true);Map<String,Object?>? u;String? problem;try{u=await AppDb.instance.login(user.text,pass.text);}catch(e){problem=e.toString().replaceFirst('Exception: ','');}if(!mounted)return;setState(()=>busy=false);if(problem!=null||u==null){ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(problem??'Non itilizatè oswa modpas pa kòrèk.')));}else{widget.onLogin(u);}},child:const Text('Konekte'))]))))));}

class HomePage extends StatefulWidget { const HomePage({super.key,required this.user}); final Map<String,Object?> user; @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage>{int tab=0; void refresh()=>setState((){});
 @override Widget build(BuildContext c){final admin=user['role']=='admin';final pages=<Widget>[DashboardPage(user:user),ProductsPage(user:user),PosPage(user:user,onDone:refresh),CashSessionPage(user:user),if(admin)SalesPage(),if(admin)AdminPage(user:user),if(admin)AuditPage()];final keys=<String>['home','products','sell','cash',if(admin)'sales',if(admin)'admin',if(admin)'audit'];final icons=<IconData>[Icons.dashboard,Icons.inventory_2,Icons.point_of_sale,Icons.point_of_sale,if(admin)Icons.receipt_long,if(admin)Icons.manage_accounts,if(admin)Icons.admin_panel_settings];final labels=keys.map((k)=>NexaLanguage.text(c,k)).toList();return Scaffold(appBar:AppBar(title:Text('NEXABIZ • ${user['full_name']}'),actions:[PopupMenuButton<String>(tooltip:NexaLanguage.text(c,'language'),icon:const Icon(Icons.language),onSelected:(code)async{await AppDb.instance.saveSetting('language',code);NexaLocale.code.value=code;await AppDb.instance.log(user['id'] as String,'LANGUAGE_CHANGE','Lang: $code');},itemBuilder:(context)=>NexaLanguage.supported.entries.map((e)=>PopupMenuItem(value:e.key,child:Text(e.value))).toList()),IconButton(onPressed:()async{await AppDb.instance.log(user['id'] as String,'LOGOUT','Dekoneksyon');if(c.mounted)Navigator.pushAndRemoveUntil(c,MaterialPageRoute(builder:(_)=>const Gate()),(_)=>false);},icon:const Icon(Icons.logout))]),body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:List.generate(labels.length,(i)=>NavigationDestination(icon:Icon(icons[i]),label:labels[i]))));}}


class DashboardPage extends StatelessWidget{const DashboardPage({super.key,required this.user});final Map<String,Object?> user;@override Widget build(BuildContext c)=>FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.products(),builder:(c,s){final rows=s.data??[];final low=rows.where((x)=>(x['stock'] as num)<=5).length;return ListView(padding:const EdgeInsets.all(16),children:[Text('Bonjou, ${user['full_name']}',style:Theme.of(c).textTheme.headlineSmall),const SizedBox(height:16),Wrap(spacing:12,runSpacing:12,children:[_stat(c,'Pwodwi aktif','${rows.length}',Icons.inventory_2),_stat(c,'Pwodwi ki prèske fini','$low',Icons.warning_amber)]),const SizedBox(height:20),const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('NEXABIZ v0.9 • Finans ak depans (baz devlopman)\n\nPremye baz aplikasyon Android la: kont administratè, pwodwi, lavant, kalkil monnen, stok ak jounal kontwòl.')))]);});}
Widget _stat(BuildContext c,String label,String value,IconData icon)=>SizedBox(width:160,child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon),Text(value,style:Theme.of(c).textTheme.headlineMedium),Text(label)]))));

class ProductsPage extends StatefulWidget{const ProductsPage({super.key,required this.user});final Map<String,Object?> user;@override State<ProductsPage> createState()=>_ProductsPageState();}
class _ProductsPageState extends State<ProductsPage>{Future<void> add()async{final n=TextEditingController(),p1=TextEditingController(),s=TextEditingController(text:'0');final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Nouvo pwodwi'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Non pwodwi')),TextField(controller:p1,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Pri (G)')),TextField(controller:s,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Kantite nan stok'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Anrejistre'))]));if(ok==true&&n.text.trim().isNotEmpty){await AppDb.instance.addProduct(n.text,double.tryParse(p1.text)??0,double.tryParse(s.text)??0,widget.user['id'] as String);setState((){});}}
@override Widget build(BuildContext c)=>Scaffold(floatingActionButton:(widget.user['role']=='admin'||widget.user['role']=='stock_manager')?FloatingActionButton(onPressed:add,child:const Icon(Icons.add)):null,body:FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.products(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.isEmpty)return const Center(child:Text('Pa gen pwodwi. Peze + pou ajoute premye a.'));return ListView(children:s.data!.map((x)=>ListTile(title:Text('${x['name']}'),subtitle:Text('${x['code']} • Stok: ${x['stock']}'),trailing:Text('${x['price']} G'))).toList());}));}

class PosPage extends StatefulWidget{const PosPage({super.key,required this.user,required this.onDone});final Map<String,Object?> user;final VoidCallback onDone;@override State<PosPage> createState()=>_PosPageState();}
class _PosPageState extends State<PosPage>{final cart=<CartLine>[];final received=TextEditingController();String method='Kach';double get total=>cart.fold(0,(s,x)=>s+x.qty*x.price);@override Widget build(BuildContext c)=>FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.products(),builder:(c,s){final products=s.data??[];return Column(children:[Expanded(child:ListView(children:products.map((p){final stock=(p['stock'] as num).toDouble();return ListTile(title:Text('${p['name']}'),subtitle:Text('Stok: $stock'),trailing:Text('${p['price']} G'),onTap:stock<=0?null:(){setState((){final i=cart.indexWhere((x)=>x.id==p['id']);if(i>=0){if(cart[i].qty<stock)cart[i].qty++;}else{cart.add(CartLine(p['id'] as String,p['name'] as String,(p['price'] as num).toDouble(),stock));}});});}).toList())),if(cart.isNotEmpty)Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Theme.of(c).colorScheme.surfaceContainer),child:Column(children:[...cart.map((x)=>Row(children:[Expanded(child:Text('${x.name} × ${x.qty}')),Text('${x.qty*x.price} G'),IconButton(onPressed:()=>setState(()=>cart.remove(x)),icon:const Icon(Icons.close))])),Text('TOTAL: ${total.toStringAsFixed(2)} G',style:Theme.of(c).textTheme.titleLarge),TextField(controller:received,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Kantite kliyan an bay (G)'),onChanged:(_)=>setState((){})),DropdownButton<String>(value:method,items:['Kach','MonCash','NatCash','Lòt'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setState(()=>method=v??'Kach')),Text('Monnen pou remèt: ${((double.tryParse(received.text)??0)-total).clamp(0,double.infinity).toStringAsFixed(2)} G'),FilledButton(onPressed:(double.tryParse(received.text)??0)<total?null:()async{try{await AppDb.instance.checkout(widget.user,cart,double.parse(received.text),method);if(!mounted)return;setState((){cart.clear();received.clear();});widget.onDone();ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Vant lan anrejistre.')));}catch(e){ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$e')));}},child:const Text('Finalize vant'))]))]);});}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key, required this.user});
  final Map<String,Object?> user;
  @override State<AdminPage> createState()=>_AdminPageState();
}
class _AdminPageState extends State<AdminPage> {
  int section=0;
  void reload()=>setState((){});
  Future<void> addExpense() async {
    final label=TextEditingController(), amount=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Anrejistre yon depans'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:label,decoration:const InputDecoration(labelText:'Pou kisa depans lan fèt?')),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Montan (G)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Anrejistre'))]));
    if(ok==true){try{await AppDb.instance.addExpense(label.text,double.tryParse(amount.text)??0,widget.user['id'] as String);reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
  }

  Future<void> addUser() async {
    final name=TextEditingController(), username=TextEditingController(), password=TextEditingController();
    String role='cashier';
    final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,dialogSet)=>AlertDialog(title:const Text('Kreye yon kont'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Non konplè')),TextField(controller:username,decoration:const InputDecoration(labelText:'Non itilizatè')),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Modpas (8 karaktè minimòm)')),DropdownButtonFormField<String>(value:role,decoration:const InputDecoration(labelText:'Wòl'),items:const [DropdownMenuItem(value:'cashier',child:Text('Kesye')),DropdownMenuItem(value:'stock_manager',child:Text('Responsab stok')),DropdownMenuItem(value:'admin',child:Text('Administratè'))],onChanged:(v)=>dialogSet(()=>role=v??'cashier'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Kreye'))])));
    if(ok==true){try{await AppDb.instance.createStaffUser(name.text,username.text,password.text,role,widget.user['id'] as String);reload();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Kont lan kreye.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Erè: $e')));}}
  }
  Future<void> editBusiness() async {
    final profile=await AppDb.instance.businessProfile();
    final name=TextEditingController(text:'${profile['business_name']??''}'), address=TextEditingController(text:'${profile['address']??''}'), phone=TextEditingController(text:'${profile['phone']??''}');
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Enfòmasyon biznis'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Non biznis la')),TextField(controller:address,decoration:const InputDecoration(labelText:'Adrès')),TextField(controller:phone,decoration:const InputDecoration(labelText:'Telefòn'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Sove'))]));
    if(ok==true){await AppDb.instance.saveBusinessProfile(name.text,address.text,phone.text,widget.user['id'] as String);reload();}
  }
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[
    Text('Sant administratè',style:Theme.of(c).textTheme.headlineSmall),
    const Text('Se administratè yo ki dwe itilize seksyon sa a.'),
    const SizedBox(height:12),
    Wrap(spacing:8,runSpacing:8,children:[(0,'Apèsi'),(1,'Itilizatè'),(2,'Biznis'),(3,'Kès'),(4,'Finans'),(5,'Anplwaye'),(6,'Prezans'),(7,'Salè'),(8,'Retou'),(9,'Sovgad')].map((x)=>ChoiceChip(label:Text(x.$2),selected:section==x.$1,onSelected:(_)=>setState(()=>section=x.$1))).toList()),
    const SizedBox(height:12),
    if(section==0) FutureBuilder<Map<String,Object?>>(future:AppDb.instance.adminSummary(),builder:(c,s){final x=s.data??{};return Column(children:[_adminTile(Icons.point_of_sale,'Total lavant','${x['sales']??0}'),_adminTile(Icons.payments,'Revni anrejistre','${x['revenue']??0} G'),_adminTile(Icons.people,'Kont aktif','${x['users']??0}'),_adminTile(Icons.inventory_2,'Pwodwi aktif','${x['products']??0}'),const Card(child:Padding(padding:EdgeInsets.all(12),child:Text('Rapò sa a montre lavant ak total anrejistre sou aparèy sa a. Li pa ranplase verifikasyon kès chak jou.')))]);}),
    if(section==1) Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[FilledButton.icon(onPressed:addUser,icon:const Icon(Icons.person_add),label:const Text('Kreye kont itilizatè')),const SizedBox(height:8),FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.allUsers(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());return Column(children:s.data!.map((u){final active=(u['active'] as int)==1;final isSelf=u['id']==widget.user['id'];final role={'admin':'Administratè','cashier':'Kesye','stock_manager':'Responsab stok'}[u['role']]??'Itilizatè';return Card(child:ListTile(title:Text('${u['full_name']}'),subtitle:Text('@${u['username']} • $role • ${active?'Aktif':'Sispann'}'),trailing:isSelf?const Chip(label:Text('Ou menm')):Switch(value:active,onChanged:(v)async{try{await AppDb.instance.setUserActive(u['id'] as String,v,widget.user['id'] as String);reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}})));}).toList());})]),
    if(section==3) _cashControl(),
    if(section==4) _financeControl(),
    if(section==5) _employeesControl(),
    if(section==6) _attendanceControl(),
    if(section==7) _payrollControl(),
    if(section==8) _returnsControl(),
    if(section==9) _backupControl(),
    if(section==2) FutureBuilder<Map<String,Object?>>(future:AppDb.instance.businessProfile(),builder:(c,s){final x=s.data??{};return Column(children:[Card(child:ListTile(leading:const Icon(Icons.store),title:Text('${x['business_name']??'Non biznis'}'),subtitle:Text('${x['address']??''}\n${x['phone']??''}'))),FilledButton.icon(onPressed:editBusiness,icon:const Icon(Icons.edit),label:const Text('Modifye enfòmasyon biznis'))]);}),
  ]);
  Future<void> _addEmployee() async {
    final n=TextEditingController(),phone=TextEditingController(),job=TextEditingController(),salary=TextEditingController(text:'0');
    final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:const Text('Nouvo anplwaye'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Non konplè')),TextField(controller:phone,decoration:const InputDecoration(labelText:'Telefòn')),TextField(controller:job,decoration:const InputDecoration(labelText:'Fonksyon')),TextField(controller:salary,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Salè baz (G)'))])),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Sove'))]));
    if(ok==true){try{await AppDb.instance.addEmployee(n.text,phone.text,job.text,double.tryParse(salary.text)??0,widget.user['id'] as String);reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
  }
  Widget _employeesControl()=>Column(children:[FilledButton.icon(onPressed:_addEmployee,icon:const Icon(Icons.person_add),label:const Text('Ajoute anplwaye')),FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.employees(),builder:(c,s){if(!s.hasData)return const CircularProgressIndicator();return Column(children:s.data!.map((e)=>Card(child:ListTile(title:Text('${e['full_name']}'),subtitle:Text('${e['employee_code']} • ${e['job_title']??''} • ${e['base_salary']} G'),trailing:Switch(value:e['active']==1,onChanged:(v)async{await AppDb.instance.setEmployeeActive(e['id'] as String,v,widget.user['id'] as String);reload();}))).toList());})]);
  Widget _attendanceControl()=>Column(children:[FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.employees(),builder:(c,s){final active=(s.data??[]).where((e)=>e['active']==1).toList();return DropdownButtonFormField<String>(decoration:const InputDecoration(labelText:'Chwazi anplwaye pou anrejistre prezans'),items:active.map((e)=>DropdownMenuItem(value:e['id'] as String,child:Text('${e['full_name']}'))).toList(),onChanged:(id)async{if(id==null)return;final picked=await showTimePicker(context:context,initialTime:const TimeOfDay(hour:8,minute:0),helpText:'Lè travay la dwe kòmanse');if(picked==null)return;final now=DateTime.now();final scheduled=DateTime(now.year,now.month,now.day,picked.hour,picked.minute);try{await AppDb.instance.clockIn(id,widget.user['id'] as String,scheduled);reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}});}),const SizedBox(height:8),FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.attendanceRows(),builder:(c,s){if(!s.hasData)return const CircularProgressIndicator();return Column(children:s.data!.map((a){final open=a['check_out']==null;return Card(child:ListTile(title:Text('${a['full_name']} • reta ${a['late_minutes']} min'),subtitle:Text('Antre: ${a['check_in']??''}\nSòti: ${a['check_out']??'Anndan'}'),trailing:open?TextButton(onPressed:()async{await AppDb.instance.clockOut(a['id'] as String,widget.user['id'] as String);reload();},child:const Text('Anrejistre sòti')):const Icon(Icons.check)));}).toList());})]);
  Future<void> _newPayroll() async {
    final employees=await AppDb.instance.employees(); if(employees.isEmpty){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Ajoute anplwaye anvan.')));return;}
    String employee=employees.first['id'] as String; final base=TextEditingController(text:'${employees.first['base_salary']}'),add=TextEditingController(text:'0'),ded=TextEditingController(text:'0'),start=TextEditingController(text:DateTime.now().toIso8601String().substring(0,10)),end=TextEditingController(text:DateTime.now().toIso8601String().substring(0,10)),note=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(d)=>StatefulBuilder(builder:(d,ss)=>AlertDialog(title:const Text('Prepare fich salè'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<String>(value:employee,items:employees.map((e)=>DropdownMenuItem(value:e['id'] as String,child:Text('${e['full_name']}'))).toList(),onChanged:(v){if(v!=null)ss(()=>employee=v);}),TextField(controller:base,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Salè baz (G)')),TextField(controller:add,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Ajout (G)')),TextField(controller:ded,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Dediksyon (G)')),TextField(controller:start,decoration:const InputDecoration(labelText:'Kòmansman peryòd YYYY-MM-DD')),TextField(controller:end,decoration:const InputDecoration(labelText:'Fen peryòd YYYY-MM-DD')),TextField(controller:note,decoration:const InputDecoration(labelText:'Nòt'))])),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Kreye fich'))])));
    if(ok==true){try{await AppDb.instance.createPayroll(employee,double.tryParse(base.text)??0,double.tryParse(add.text)??0,double.tryParse(ded.text)??0,start.text,end.text,note.text,widget.user['id'] as String);reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
  }
  Widget _payrollControl()=>Column(children:[FilledButton.icon(onPressed:_newPayroll,icon:const Icon(Icons.add),label:const Text('Kreye fich salè')),const Padding(padding:EdgeInsets.all(8),child:Text('Nenpòt dediksyon dwe verifye davans ak kontra travay la ak lwa travay Ayiti; sistèm nan pa aplike penalite otomatikman.')),FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.payrollRows(),builder:(c,s){if(!s.hasData)return const CircularProgressIndicator();return Column(children:s.data!.map((r)=>Card(child:ListTile(title:Text('${r['full_name']} • ${r['net_amount']} G'),subtitle:Text('${r['period_start']} → ${r['period_end']} • ${r['status']}\nBaz ${r['base_amount']} + ${r['additions']} - ${r['deductions']}'),trailing:r['status']=='pending'?TextButton(onPressed:()async{await AppDb.instance.markPayrollPaid(r['id'] as String,widget.user['id'] as String);reload();},child:const Text('Make peye')):const Icon(Icons.check_circle)))).toList());})]);
  Widget _returnsControl()=>Column(children:[FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.salesWithItems(),builder:(c,s){if(!s.hasData)return const CircularProgressIndicator();return Column(children:s.data!.map((sale)=>Card(child:ListTile(title:Text('${sale['receipt_no']} • ${sale['total']} G'),subtitle:Text('${sale['cashier_name']} • ${sale['created_at']}'),trailing:TextButton(onPressed:()async{final items=await AppDb.instance.itemsForSale(sale['id'] as String);if(!mounted)return;showDialog(context:context,builder:(d)=>AlertDialog(title:const Text('Chwazi atik pou retounen'),content:SingleChildScrollView(child:Column(children:items.map((it)=>ListTile(title:Text('${it['product_name']}'),subtitle:Text('Vann: ${it['quantity']} × ${it['unit_price']} G'),onTap:()async{Navigator.pop(d);final q=TextEditingController(text:'1'),reason=TextEditingController();String action='RESTOCK';final ok=await showDialog<bool>(context:context,builder:(x)=>StatefulBuilder(builder:(x,ss)=>AlertDialog(title:const Text('Trete retou'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Kantite retounen')),TextField(controller:reason,decoration:const InputDecoration(labelText:'Rezon retou')),DropdownButtonFormField<String>(value:action,items:const [DropdownMenuItem(value:'RESTOCK',child:Text('Remete nan stok')),DropdownMenuItem(value:'NO_RESTOCK',child:Text('Pa remete nan stok'))],onChanged:(v)=>ss(()=>action=v??'RESTOCK'))]),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('Konfime'))])));if(ok==true){try{await AppDb.instance.processReturn(it,sale['id'] as String,double.tryParse(q.text)??0,reason.text,action,widget.user['id'] as String);reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}})).toList())),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Fèmen'))]));},child:const Text('Retou')))).toList());})]);
  Widget _backupControl()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Text('Sovgad la gen done biznis, lavant, stok, anplwaye, prezans, salè ak jounal kontwòl. Kenbe fichye a yon kote ki an sekirite.'),const SizedBox(height:12),FilledButton.icon(onPressed:()async{try{await AppDb.instance.exportBackup();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Sovgad la pare pou pataje oswa konsève.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}},icon:const Icon(Icons.upload_file),label:const Text('Ekspòte sovgad')),const SizedBox(height:8),OutlinedButton.icon(onPressed:()async{final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:const Text('Atansyon: retabli sovgad'),content:const Text('Retabli yon sovgad ranplase done ki sou aparèy sa a. Fè yon sovgad aktyèl anvan. Kontinye?'),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Kontinye'))]));if(ok==true){try{await AppDb.instance.importBackup();reload();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Sovgad retabli.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}},icon:const Icon(Icons.download),label:const Text('Retabli yon sovgad'))]);
  Widget _financeControl()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    FutureBuilder<Map<String,Object?>>(future:AppDb.instance.financeSummary(),builder:(c,s){final x=s.data??{};return Column(children:[_adminTile(Icons.point_of_sale,'Total lavant','${x['sales']??0} G'),_adminTile(Icons.receipt_long,'Kantite lavant','${x['count']??0}'),_adminTile(Icons.money_off,'Depans anrejistre','${x['expenses']??0} G'),_adminTile(Icons.payments,'Salè deja peye','${x['payroll']??0} G'),_adminTile(Icons.assignment_return,'Ranbousman','${x['refunds']??0} G'),_adminTile(Icons.account_balance,'Rès pwovizwa','${x['net_before_stock_cost']??0} G'),const Padding(padding:EdgeInsets.all(8),child:Text('Sa se yon rezilta pwovizwa. Li poko retire pri acha machandiz, taks oswa lòt chaj ki poko antre nan sistèm nan.'))]);}),
    FilledButton.icon(onPressed:addExpense,icon:const Icon(Icons.add),label:const Text('Anrejistre depans')),
    const SizedBox(height:8),FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.expenses(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.isEmpty)return const Text('Pa gen depans anrejistre.');return Column(children:s.data!.map((e)=>Card(child:ListTile(leading:const Icon(Icons.money_off),title:Text('${e['label']} • ${e['amount']} G'),subtitle:Text('${e['full_name']??'Itilizatè'} • ${e['created_at']}'))).toList());})
  ]);
  Widget _cashControl()=>FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.cashSessions(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());if(s.data!.isEmpty)return const Padding(padding:EdgeInsets.all(18),child:Text('Pa gen sesyon kès anrejistre.'));return Column(children:s.data!.map((x){final open=x['closed_at']==null;return Card(child:ListTile(leading:Icon(open?Icons.lock_open:Icons.lock),title:Text('${x['full_name']??'Itilizatè'} • ${open?'Kès ouvè':'Kès fèmen'}'),subtitle:Text('Ouvèti: ${x['opening_cash']} G\nDat: ${x['opened_at']}\n'+(open?'':'Konte: ${x['counted_cash']} G • Atann: ${x['expected_cash']} G')),trailing:IconButton(icon:const Icon(Icons.receipt_long),onPressed:()async{final r=await AppDb.instance.cashSessionReport(x['id'] as String);if(!mounted)return;showDialog(context:context,builder:(d)=>AlertDialog(title:const Text('Rapò sesyon kès'),content:Text('Vant: ${r['sales_count']}\nTotal lavant: ${r['sales_total']} G\nLavant kach: ${r['cash_sales']} G\nLajan atann nan kès: ${r['expected']} G'),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Fèmen'))]));})));}).toList());});
  Widget _adminTile(IconData icon,String title,String value)=>Card(child:ListTile(leading:Icon(icon),title:Text(title),trailing:Text(value,style:Theme.of(context).textTheme.titleLarge)));
}

class SalesPage extends StatelessWidget{const SalesPage({super.key});@override Widget build(BuildContext c)=>FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.recentSales(),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());return ListView(children:s.data!.map((x)=>ListTile(title:Text('${x['receipt_no']} • ${x['total']} G'),subtitle:Text('${x['cashier_name']} • Resevwa: ${x['amount_received']} G • Monnen: ${x['change_given']} G'),trailing:Text('${x['payment_method']}'))).toList());});}
class AuditPage extends StatelessWidget{const AuditPage({super.key});@override Widget build(BuildContext c)=>FutureBuilder<List<Map<String,Object?>>>(future:AppDb.instance.db.rawQuery('''SELECT audit_logs.*, users.full_name FROM audit_logs LEFT JOIN users ON users.id=audit_logs.user_id ORDER BY audit_logs.created_at DESC LIMIT 200'''),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());return ListView(children:s.data!.map((x)=>ListTile(title:Text('${x['action']} • ${x['full_name']??'Sistèm'}'),subtitle:Text('${x['details']}\n${x['created_at']}'))).toList());});}

class CashSessionPage extends StatefulWidget {
  const CashSessionPage({super.key,required this.user});
  final Map<String,Object?> user;
  @override State<CashSessionPage> createState()=>_CashSessionPageState();
}
class _CashSessionPageState extends State<CashSessionPage> {
  final amount=TextEditingController();
  bool busy=false;
  Future<void> refresh() async { if(mounted)setState((){}); }
  Future<void> open() async {
    final value=double.tryParse(amount.text);
    if(value==null||value<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Antre lajan ouvèti a kòrèk.')));return;}
    try{await AppDb.instance.openCashSession(widget.user['id'] as String,value);amount.clear();await refresh();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }
  Future<void> close(Map<String,Object?> session) async {
    final report=await AppDb.instance.cashSessionReport(session['id'] as String);
    final counted=TextEditingController(text:'${report['expected']}');
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Fèmen kès la'),content:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Lajan ki ta dwe nan kès la: ${report['expected']} G'),TextField(controller:counted,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Lajan ou konte toutbon (G)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Anile')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Konfime fèmti'))]));
    if(ok==true){final n=double.tryParse(counted.text);if(n==null||n<0)return;await AppDb.instance.closeCashSession(session['id'] as String,n,widget.user['id'] as String);await refresh();}
  }
  @override Widget build(BuildContext c)=>FutureBuilder<Map<String,Object?>?>(future:AppDb.instance.activeCashSession(widget.user['id'] as String),builder:(c,s){if(!s.hasData&&s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());final session=s.data;return ListView(padding:const EdgeInsets.all(16),children:[Text('Kès mwen',style:Theme.of(c).textTheme.headlineSmall),const SizedBox(height:12),if(session==null)...[const Text('Pa gen kès ouvè pou kont sa a.'),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Lajan kòmansman kès la (G)')),const SizedBox(height:10),FilledButton.icon(onPressed:open,icon:const Icon(Icons.lock_open),label:const Text('Ouvri kès'))]else...[(FutureBuilder<Map<String,Object?>>(future:AppDb.instance.cashSessionReport(session['id'] as String),builder:(c,r){final x=r.data??{};return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Sesyon an aktif',style:TextStyle(fontWeight:FontWeight.bold)),Text('Lajan ouvèti: ${x['opening']??0} G'),Text('Kantite lavant: ${x['sales_count']??0}'),Text('Total lavant: ${x['sales_total']??0} G'),Text('Lavant kach: ${x['cash_sales']??0} G'),Text('Lajan ki ta dwe nan kès la: ${x['expected']??0} G')])));}),const SizedBox(height:12),FilledButton.icon(onPressed:()=>close(session),icon:const Icon(Icons.lock),label:const Text('Fèmen kès epi konte lajan'))]]);});
}
